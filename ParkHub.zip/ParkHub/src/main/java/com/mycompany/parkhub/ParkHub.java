package com.mycompany.parkhub;

public class ParkHub {

    public static void main(String[] args) {
       
        Inicio ventana = new Inicio();
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);
        
        Juego ventana2 = new Juego(ventana);
        ventana2.setVisible(false);
    }
}