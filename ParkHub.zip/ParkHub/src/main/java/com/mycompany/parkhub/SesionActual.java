package com.mycompany.parkhub;

public class SesionActual {
    public static Jugador jugadorActual;
}
