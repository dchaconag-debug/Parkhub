package com.mycompany.parkhub;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;

public class JugadorDAO {
    public boolean insertarJugador(String nombre) {
        String sql = "INSERT INTO jugadores (nombre) VALUES (?)";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nombre);
            stmt.executeUpdate();
            return true;

        } catch (SQLException e) {
            System.out.println("Error al insertar jugador: " + e.getMessage());
            return false;
        }
    }

    public Jugador obtenerUltimoJugador() {
        String sql = "SELECT id, nombre FROM jugadores ORDER BY id DESC LIMIT 1";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                int id = rs.getInt("id");
                String nombre = rs.getString("nombre");
                return new Jugador(id, nombre); 
            }

        } catch (SQLException e) {
            System.out.println("Error al obtener jugador: " + e.getMessage());
        }

        return null;
    }
}
