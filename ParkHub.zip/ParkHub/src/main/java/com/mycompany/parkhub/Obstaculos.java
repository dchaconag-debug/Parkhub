package com.mycompany.parkhub;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class Obstaculos extends JPanel{
    private Image imagen;
    
    public Obstaculos(String tipo){
        if (tipo.equals("carro")){
            imagen = new ImageIcon(getClass().getResource("/img/obstaculocarro.png")).getImage();
        } else if (tipo.equals("muro")){
            imagen = new ImageIcon(getClass().getResource("/img/obstaculomuro.png")).getImage();
        }
        setSize(imagen.getWidth(null), imagen.getHeight(null));
        setOpaque(false);
    }
    
    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        Graphics g2d = (Graphics2D) g;
        g.drawImage(imagen, 0, 0, this);
        
        g2d.setColor(Color.BLUE);
        Rectangle r = getBounds();
     // g2d.drawRect(0, 0, r.width - 1, r.height -1);
    }   
    
}
