package com.mycompany.parkhub;

import com.mycompany.parkhub.ConexionBD;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PartidaDAO {

    public boolean insertarPartida(int idJugador) {
    String sql = "INSERT INTO partidas (id_jugador, puntos) VALUES (?, 100)";
    try (Connection conn = ConexionBD.conectar();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, idJugador);
        stmt.executeUpdate();
        return true;
    } catch (SQLException e) {
        return false;
    }
    
}
    public int obtenerPuntajeTotal(int idJugador) {
    String sql = "SELECT SUM(puntos) FROM partidas WHERE id_jugador = ?";
    try (Connection conn = ConexionBD.conectar();
         PreparedStatement stmt = conn.prepareStatement(sql)) {
        stmt.setInt(1, idJugador);
        var rs = stmt.executeQuery();
        if (rs.next()) {
            return rs.getInt(1);
        }
    } catch (SQLException e) {
    }
    return 0;
}

}
    