package com.mycompany.parkhub;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.Shape;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

public class Juego extends javax.swing.JFrame {
    
    private Inicio inicio;
    private double angulo = 0;
    private int x = 360, y = 190;
    private CarroPanel carro;
    private Parqueadero parqueadero;
    ArrayList<Obstaculos> obstaculos = new ArrayList<>();
    
    class FondoPanel extends JPanel {
        private Image imagen;
        
        public FondoPanel(){
            java.net.URL ruta = getClass().getResource("/img/nivel1.jpg");
            imagen = new ImageIcon(ruta).getImage();
        }
        
        @Override   
        protected void paintComponent(Graphics g){
            super.paintComponent(g);
            g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this);
        } 
    }
    
    class CarroPanel extends JPanel {
        private Image imagen;
        public int anchoCarro;
        public int altoCarro;
                        
        public CarroPanel(){
            imagen = new ImageIcon(getClass().getResource("/img/carro.png")).getImage();
            anchoCarro = imagen.getWidth(null);
            altoCarro = imagen.getHeight(null);
            
            int max = (int) Math.hypot(anchoCarro, altoCarro);
            setSize(max, max);
            setOpaque(false);
        }
        

        @Override
        protected void paintComponent(Graphics g){
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            
            AffineTransform at = new AffineTransform();
            at.translate(getWidth() / 2, getHeight() / 2);
            at.rotate(Math.toRadians(angulo));
            at.translate(-anchoCarro / 2, -altoCarro / 2);
            g2d.drawImage(imagen, at, null);
            g2d.setColor(java.awt.Color.RED);
        //  g2d.draw(at.createTransformedShape(
        //  new Rectangle(0, 0, anchoCarro, altoCarro)));
        }
        public Shape getColicionShape() {
            AffineTransform at = new AffineTransform();

            int offsetX = (getWidth() - anchoCarro) / 2;
            int offsetY = (getHeight() - altoCarro) / 2;
            at.translate(getX() + offsetX + anchoCarro / 2.0, getY() + offsetY + altoCarro / 2.0);
            at.rotate(Math.toRadians(angulo));
            at.translate(-anchoCarro / 2.0, -altoCarro / 2.0);
            return at.createTransformedShape(new Rectangle(0, 0, anchoCarro, altoCarro));
}

    }
    
    class Parqueadero extends JPanel {
        private Image imagen;
        
        public Parqueadero(){
            imagen = new ImageIcon(getClass().getResource("/img/parqueadero.png")).getImage();
            setSize(imagen.getWidth(null), imagen.getHeight(null));
            setOpaque(false);
        }
        
        @Override
        protected void paintComponent(Graphics g){
            super.paintComponent(g);
            g.drawImage(imagen, 0, 0, this);
        }
    }
    public Juego(Inicio inicio) {
        FondoPanel fondo = new FondoPanel();
        this.setContentPane(fondo);
        
        initComponents();
        
        this.inicio = inicio;
      
        parqueadero = new Parqueadero();
        parqueadero.setBounds(25, 105, parqueadero.getWidth(), parqueadero.getHeight());
        add(parqueadero);
        carro = new CarroPanel();
        carro.setBounds((int)x, (int)y, carro.getWidth(), carro.getHeight());
        add(carro);        
        
        Obstaculos o1 = new Obstaculos("carro");
        o1.setBounds(97, 105, o1.getWidth(), o1.getHeight());
        obstaculos.add(o1);
        Obstaculos o3 = new Obstaculos("carro");
        o3.setBounds(380, 105, o3.getWidth(), o3.getHeight());
        obstaculos.add(o3);
        Obstaculos o4 = new Obstaculos("carro");
        o4.setBounds(380, 252, o4.getWidth(), o4.getHeight());
        obstaculos.add(o4);
        Obstaculos o5 = new Obstaculos("carro");
        o5.setBounds(250, 252, o5.getWidth(), o5.getHeight());
        obstaculos.add(o5);
        Obstaculos o7 = new Obstaculos("carro");
        o7.setBounds(155, 252, o7.getWidth(), o7.getHeight());
        obstaculos.add(o7);
        Obstaculos o6 = new Obstaculos("carro");
        o6.setBounds(90, 252, o6.getWidth(), o6.getHeight());
        obstaculos.add(o6);
        Obstaculos o8 = new Obstaculos("carro");
        o8.setBounds(25, 252, o8.getWidth(), o8.getHeight());
        obstaculos.add(o8);
        
        Obstaculos o2 = new Obstaculos("muro");
        o2.setBounds(210, 30, o2.getWidth(), o2.getHeight());
        obstaculos.add(o2);
        Obstaculos o9 = new Obstaculos("muro");
        o9.setBounds(435, 250, o9.getWidth(), o9.getHeight());
        obstaculos.add(o9);
        Obstaculos o10 = new Obstaculos("muro");
        o10.setBounds(435, 30, o10.getWidth(), o10.getHeight());
        obstaculos.add(o10);
        Obstaculos o11 = new Obstaculos("muro");
        o11.setBounds(210, 250, o11.getWidth(), o11.getHeight());
        obstaculos.add(o11);
        
        for (Obstaculos o : obstaculos){ add(o); }
        
        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e){
                int key = e.getKeyCode();
                int paso = 5;
                double giro = 5;

                if (key == KeyEvent.VK_LEFT){
                    angulo -= giro;
                }
                if (key == KeyEvent.VK_RIGHT){
                    angulo += giro;
                }
                if (key == KeyEvent.VK_UP){
                    x -= paso * Math.cos(Math.toRadians(angulo));                    
                    y -= paso * Math.sin(Math.toRadians(angulo));                    
                }
                if (key == KeyEvent.VK_DOWN){
                    x += paso * Math.cos(Math.toRadians(angulo));
                    y += paso * Math.sin(Math.toRadians(angulo));
                }
                
                carro.setLocation(x,y);
                System.out.print("Carro en: x = " + x + ", y = " + y);
                carro.repaint();
                verificarParqueo();
                verificarColisionObstaculos();
            }
        });
        
        setFocusable(true);
        requestFocusInWindow();
            
    }
    
    private void verificarParqueo(){
        
        int carroX = carro.getX();
        int carroY = carro.getY();
        int parqueaderoX = parqueadero.getX();
        int parqueaderoY = parqueadero.getY();
        
        boolean parqueado = (Math.abs(carroX - parqueaderoX) <= 15) &&
                            (Math.abs(carroY - parqueaderoY) <= 5);
        
        if (parqueado){
            System.out.println("PARQUEO!!");
            
            new Ganaste().setVisible(true);
            this.dispose();
        }    
    }
    
    private void verificarColisionObstaculos(){
        Shape carroShape = carro.getColicionShape();
        
        for (Obstaculos obst : obstaculos) {
            Shape obstShape = new Rectangle(obst.getX(), obst.getY(), obst.getWidth(), obst.getHeight());
            
            Area areaCarro = new Area(carroShape);
            areaCarro.intersect(new Area(obstShape));
            
            if (!areaCarro.isEmpty()) {
                System.out.println("Carro en X: "+ carro.getX() + ", carro en Y: " + carro.getY());
                System.out.println("Obstaculo en X: " + obst.getX() + ", Obst en Y: " + obst.getY());
                new Perdiste().setVisible(true);
                this.dispose();
                break;
            }
        }
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        Botonmenu = new javax.swing.JButton();

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setBackground(java.awt.SystemColor.control);
        jLabel1.setFont(new java.awt.Font("Segoe UI Emoji", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("NIVEL 1");

        Botonmenu.setText("Menú");
        Botonmenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BotonmenuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 308, Short.MAX_VALUE)
                .addComponent(Botonmenu)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Botonmenu))
                .addContainerGap(394, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BotonmenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BotonmenuActionPerformed
        this.setVisible(false);
        inicio.setVisible(true);
        inicio.setLocationRelativeTo(null);
    }//GEN-LAST:event_BotonmenuActionPerformed
   
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Botonmenu;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}